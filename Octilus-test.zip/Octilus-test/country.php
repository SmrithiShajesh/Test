<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
</html>
<?php

function getSelectOfCountries($chosenCountry = null)
{

  $countries = array('Afganistan', 'Albania', 'Algeria','Guinea-Bissau','Guyana','Haiti','Holy See','Honduras','Hungary','Iceland','India','Indonesia','Iran','Iraq');
  echo "<select  class='input-field' name='country' id='country'>\n";
  echo "<option value=''>Select a Country</option>\n";
  foreach ($countries as $country)
  {
    echo "<option value='$country'";
    if ($chosenCountry == $country)
    {
      echo " selected='selected'";
    }
    echo ">$country</option>\n";
  }
}

?>