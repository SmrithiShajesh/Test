<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<title>Untitled Document</title>

<script type="text/javascript">
function validation()
{
  var name=/^[a-zA-Z .]+$/; 
  var password=/^[a-zA-Z0-9]{4,8}$/;
  var confirmpassword=/^[a-zA-Z0-9]{4,8}$/;    
  var email=/^[\w\-\.\+]+@[a-za-z0-9\.\-]+\.[a-zA-Z0-9]{2,4}$/;

 if(document.getElementById('email').value.length==0)
 {
   alert("please enter email");
   document.getElementById('email').focus();
   return false;
   }
  
    else if(!document.getElementById('email').value.match(email))
   {
     alert("does not match emailid..please enter correctly...");
	 document.getElementById('email').focus();
	 return false;
   } 
   else if(document.getElementById('pwd').value.length==0)
 {
   alert("please enter password");
   document.getElementById('pwd').focus();
   return false;
   }
   else if(!document.getElementById('pwd').value.match(password))
   {
     alert("does not match password..please enter correctly...");
	 document.getElementById('pwd').focus();
	 return false;
   }
    else if(document.getElementById('rpwd').value.length==0)
 {
   alert("please re-type password");
   document.getElementById('rpwd').focus();
   return false;
   }
  else if(!document.getElementById('rpwd').value.match(confirmpassword))
   {
     alert("does not match  password..please enter correctly...");
	 document.getElementById('rpwd').focus();
	 return false;
   }
  else if(!document.getElementById('pwd').value.match(document.getElementById('rpwd').value))
   {
     alert("does not match password..please enter correctly...");
	 
	 return false;
   }
  else if(document.getElementById('fn').value.length==0)
 {
   alert("please enter your first name");
   document.getElementById('fn').focus();
   return false;
   }
   else if(!document.getElementById('fn').value.match(name))
   {
     alert("does not match name..please enter correctly...");
	 document.getElementById('fn').focus();
	 return false;
   }
   else if(document.getElementById('ln').value.length==0)
 {
   alert("please enter your last name");
   document.getElementById('ln').focus();
   return false;
   }
   else if(!document.getElementById('ln').value.match(name))
   {
     alert("does not match name..please enter correctly...");
	 document.getElementById('ln').focus();
	 return false;
   }
  
   else if(document.getElementById('gm').checked==false && document.getElementById('gf').checked==false )
 {
   alert("please check gender");
   document.getElementById('gm').focus();
   return false;
   }  
  else if(document.getElementById('country').value=="")
 {
   alert("please select country");
   document.getElementById('country').focus();
   return false;
   }
   else if(!document.getElementById('ag').checked == true){
   alert('You must agree to the terms first.');
    return false;
   }
    else if(!document.getElementById('wt').checked == true){
   alert('You want to receive the newsletter.');
    return false;
   }
   else
  {
    return true;
  }
}
</script>


</head>

<body>
<center>
<?php
require "country.php";
?>
<center><h1>User Registration</h1>
<form method="post" enctype="multipart/form-data">

<table class="input-icons"><tr><td><i class="fa fa-envelope icon">
              </i><input class="input-field" type="text" name="email" id="email" placeholder="Email"></td></tr>
<tr><td><i class="fa fa-lock icon">
              </i><input class="input-field" type="password" name="pwd" id="pwd" placeholder="Password"></td></tr>
<tr><td><i class="fa fa-lock icon">
              </i><input class="input-field" type="password" name="rpwd" id="rpwd" placeholder="Re-type password"></td></tr>
             
<tr><td><i class="fa fa-user icon">
              </i><input class="input-field" type="text" name="fn"  id="fn" placeholder="First Name"></td></tr>
<tr><td><i class="fa fa-user icon">
              </i><input class="input-field" type="text" name="ln"  id="ln" placeholder="Last Name"></td></tr>
<tr><td>Male<input  type="radio" name="g" id="gm" value="Male">Female<input type="radio" name="g" id="gf" value="Female"></td></tr>
<tr><td><?php getSelectOfCountries();?></td></tr>

<tr><td><input class="input-field" type="checkbox" id="ag" value="ag" /> I agree with terms and conditions</td></tr>
<tr><td><input class="input-field" type="checkbox" id="wt" value="wt" />I want to receive the newsletter</td></tr>
</td></tr>
<tr><td><input  type="submit" value="REGISTER" name="submit" class="button" onClick="return validation();"></td></tr>
</table>
<a href="index.php">Home</a>
</form>
<?php
	$con=mysqli_connect("localhost","root","","octilus_db");
	if(isset($_POST['submit']))
	{
	
	$fname=$_POST['fn'];
	$lname=$_POST['ln'];
	$gender=$_POST['g'];
	$email=$_POST['email'];
	$country=$_POST['country'];
	$password=$_POST['pwd'];
	$d="INSERT INTO `user`(`firstName`, `lastName`, `gender`, `country`, `email`, `password`) VALUES ('$fname','$lname','$gender','$country','$email','$password')";
	mysqli_query($con,$d);
	}
	?>
	</center>
</body>
</html>