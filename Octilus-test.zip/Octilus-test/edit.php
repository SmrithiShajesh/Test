
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" type="text/css" href="css/style.css">
<title>form1</title>
<script type="text/javascript">
function validation()
{
  var name=/^[a-zA-Z .]+$/; 
  var password=/^[a-zA-Z0-9]{4,8}$/;
  var confirmpassword=/^[a-zA-Z0-9]{4,8}$/;    
  var email=/^[\w\-\.\+]+@[a-za-z0-9\.\-]+\.[a-zA-Z0-9]{2,4}$/;

 if(document.getElementById('fn').value.length==0)
 {
   alert("please enter your first name");
   document.getElementById('fn').focus();
   return false;
   }
   else if(!document.getElementById('fn').value.match(name))
   {
     alert("does not match name..please enter correctly...");
	 document.getElementById('fn').focus();
	 return false;
   }
   else if(document.getElementById('ln').value.length==0)
 {
   alert("please enter your last name");
   document.getElementById('ln').focus();
   return false;
   }
   else if(!document.getElementById('ln').value.match(name))
   {
     alert("does not match name..please enter correctly...");
	 document.getElementById('ln').focus();
	 return false;
   }
  
  else if(document.getElementById('email').value.length==0)
 {
   alert("please enter email");
   document.getElementById('email').focus();
   return false;
   }
  
    else if(!document.getElementById('email').value.match(email))
   {
     alert("does not match emailid..please enter correctly...");
	 document.getElementById('email').focus();
	 return false;
   } 

  else if(document.getElementById('gm').checked==false && document.getElementById('gf').checked==false )
 {
   alert("please check gender");
   document.getElementById('gm').focus();
   return false;
   }  
  else if(document.getElementById('country').value=="")
 {
   alert("please select country");
   document.getElementById('country').focus();
   return false;
   }
   else
  {
    return true;
  }
}
</script>
</head>

<body>
<?php
require "country.php";
$con=mysqli_connect("localhost","root","","octilus_db");
$idd=$_GET['pid'];
$sql="select * from user where id='$idd'";
$exe=mysqli_query($con,$sql);
$fetch=mysqli_fetch_array($exe);
?>
<form method="post" >
<table><tr><td><b>User Registration</b></td></tr>
<tr><td>First Name :</td><td><input type="text" name="fn" id="fn" value="<?php echo $fetch['firstName'];?>" /></td></tr>
<tr><td>Last Name :</td><td><input type="text" name="ln" id="ln" value="<?php echo $fetch['lastName'];?>" /></td></tr>
<tr><td>Email :</td><td><input type="text" name="email" id="email" value="<?php echo $fetch['email'];?>" /></td></tr>
<tr><td>Gender :</td><td>male<input type="radio" name="g"  id="gm" value="male" <?php if($fetch['gender']=="Male"){?> checked="checked"<?php }?>  />female<input type="radio" name="g" value="female" id="gf" <?php if($fetch['gender']=="Female"){?> checked="checked"<?php }?> /></td></tr>
<tr><td>Country : </td><td><?php getSelectOfCountries($fetch['country']);?></td></tr>
</table>
<input type="submit" name="submit" value="UPDATE" class="action" onClick="return validation();" />
</form>
</body>
<?php
if(isset($_POST['submit']))
{
$fname=$_POST['fn'];
$lname=$_POST['ln'];
$email=$_POST['email'];
$gender=$_POST['g'];
$country=$_POST['country'];


$sql="update user set firstName='$fname',lastName='$lname',gender='$gender',country='$country',email='$email' where id='$idd'";
mysqli_query($con,$sql);
header("location:view.php");
}
?>
