
<?php
$con=mysqli_connect("localhost","root","","octilus_db");
$idd=$_GET['idd'];
$sql="delete from user where id='$idd'";
mysqli_query($con,$sql);
header("location:view.php");
?>