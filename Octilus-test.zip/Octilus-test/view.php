
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

<link rel="stylesheet" type="text/css" href="css/table.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<title>form1</title>
</head>
<body>
<center>
<table>
<tr>

<th>Username</th>
<th>Email</th>
<th>Gender</th>
<th>Country</th>
<th>Action</th>
</tr>
<tr>

<?php
$con=mysqli_connect("localhost","root","","octilus_db");
if(isset($_GET['page']))
{
	$page=$_GET['page'];
}
else
{
$page=1;
}
$num_per_page=3;
$start_from=($page-1)*$num_per_page;

$sql="select * from user limit $start_from,$num_per_page";
$exe=mysqli_query($con,$sql);
$sql1="select * from user";
$exe1=mysqli_query($con,$sql1);

$total_records=mysqli_num_rows($exe1);
$total_pages=ceil($total_records/$num_per_page);

while($fetch=mysqli_fetch_array($exe))
{
?>
<td><?php echo $fetch['firstName'].' '.$fetch['lastName'];?></td>
<td><?php echo $fetch['email'];?></td>
<td><?php echo $fetch['gender'];?></td>
<td><?php echo $fetch['country'];?></td>
<td><a href="edit.php?pid=<?php echo $fetch['id'];?>" class="action">Edit</a>
<a href="delete.php?idd=<?php echo $fetch['id']; ?>" onclick="return confirm('Are you sure you want to delete this entry?')" class="action">Delete</a></td>

</tr>

<?php
}
?>
</table>

<?php
if($page>1)
{
	?>
    
<a href="view.php?page=<?php echo $page-1;?>">prev</a>
<?php
}
?>
<?php
for($i=1;$i<=$total_pages;$i++)
{
	?>
    <a href="view.php?page=<?php echo $i;?>"><?php echo $i;?></a>
    <?php
}
?>

<?php
if($page<$total_pages)
{
	?>
<a href="view.php?page=<?php echo $page+1;?>">next</a>
<?php
}
?>
<a href="index.php">Home</a>
</center>
</body>
</html>


